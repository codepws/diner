package com.imooc.restaurants;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestaurantApplicationTest {

}