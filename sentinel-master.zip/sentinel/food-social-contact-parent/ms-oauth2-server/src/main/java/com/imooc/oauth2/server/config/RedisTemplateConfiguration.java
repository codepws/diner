package com.imooc.oauth2.server.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;

// @Configuration
public class RedisTemplateConfiguration {

    // @Bean
    public RedisConnectionFactory lettuceConnectionFactory() {
        RedisSentinelConfiguration sentinelConfiguration = new RedisSentinelConfiguration()
                .master("mymaster")
                .sentinel("192.168.10.101", 26379)
                .sentinel("192.168.10.102", 26379)
                .sentinel("192.168.10.103", 26379);
        sentinelConfiguration.setDatabase(1);
        sentinelConfiguration.setPassword("123456");
        return new LettuceConnectionFactory(sentinelConfiguration);
    }

}